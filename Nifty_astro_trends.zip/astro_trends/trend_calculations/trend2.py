def compute(sun, nakshatra):
    return f"{sun}_{nakshatra}_trend"

