def compute(sun, tithi, paksha):
    return f"{sun}_{tithi}_{paksha}_trend"

