def compute(sun, moon):
    return f"{sun}_{moon}_trend"

