
import swisseph as swe
from openpyxl import Workbook
from datetime import datetime, timedelta
from trend_rules.trend1 import compute as compute_trend1
from trend_rules.trend2 import compute as compute_trend2
from trend_rules.trend3 import compute as compute_trend3

# ➤ Configure Swiss Ephemeris for KP(New) ayanamsa
swe.set_ephe_path(".")
swe.set_sid_mode(swe.SIDM_KRISHNAMURTI)

# ➤ Rashi, Nakshatra, and Tithi tables
RASHI = [
    "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
    "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"
]

NAKSHATRAS = [
    "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira", "Ardra",
    "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni", "Uttara Phalguni",
    "Hasta", "Chitra", "Swati", "Vishakha", "Anuradha", "Jyeshtha", "Mula",
    "Purva Ashadha", "Uttara Ashadha", "Shravana", "Dhanishta", "Shatabhisha",
    "Purva Bhadrapada", "Uttara Bhadrapada", "Revati"
]

TITHIS = [
    "Pratipada", "Dvitiya", "Tritiya", "Chaturthi", "Panchami", "Shashthi", "Saptami", "Ashtami",
    "Navami", "Dashami", "Ekadashi", "Dwadashi", "Trayodashi", "Chaturdashi", "Purnima",
    "Pratipada", "Dvitiya", "Tritiya", "Chaturthi", "Panchami", "Shashthi", "Saptami", "Ashtami",
    "Navami", "Dashami", "Ekadashi", "Dwadashi", "Trayodashi", "Chaturdashi", "Amavasya"
]

def sidereal_deg(jd, planet):
    ayanamsa = swe.get_ayanamsa_ut(jd)
    return (swe.calc_ut(jd, planet)[0][0] - ayanamsa) % 360

# ➤ Workbook setup
wb = Workbook()
ws = wb.active
ws.title = "Nifty Prediction 2025"

ws.append([
    "Date", "Day", "Sun Sign", "Moon Sign", "Trend1 (Sun + Moon)",
    "Moon Nakshatra", "Trend2 (Sun + Nakshatra)", "Tithi", "Paksha",
    "Trend3 (Sun + Tithi + Paksha)", "Actual", "Mercury Sign", "Venus Sign", "Mars Sign"
])

# ➤ Main loop for each day of 2025

start_date = datetime(2025, 1, 1)
for i in range(365):
    date = start_date + timedelta(days=i)
    jd = swe.julday(date.year, date.month, date.day, 10.0)  # 10:00 AM IST

    sun = sidereal_deg(jd, swe.SUN)
    moon = sidereal_deg(jd, swe.MOON)
    mercury = sidereal_deg(jd, swe.MERCURY)
    venus = sidereal_deg(jd, swe.VENUS)
    mars = sidereal_deg(jd, swe.MARS)

    sun_sign = RASHI[int(sun // 30)]
    moon_sign = RASHI[int(moon // 30)]
    mercury_sign = RASHI[int(mercury // 30)]
    venus_sign = RASHI[int(venus // 30)]
    mars_sign = RASHI[int(mars // 30)]

    nakshatra = NAKSHATRAS[int(moon // (360 / 27))]
    angle = (moon - sun) % 360
    tithi = TITHIS[int(angle // 12)]
    paksha = "Shukla" if angle < 180 else "Krishna"

    t1 = compute_trend1(sun_sign, moon_sign)
    t2 = compute_trend2(sun_sign, nakshatra)
    t3 = compute_trend3(sun_sign, paksha, tithi)

    ws.append([
        date.strftime('%d-%b-%Y'), date.strftime('%A'),
        sun_sign, moon_sign, t1,
        nakshatra, t2, tithi, paksha, t3,
        "", mercury_sign, venus_sign, mars_sign
    ])

# ➤ Save output
wb.save(r"C:\Users\GOUR CHANDRA PAUL\nifty_prediction_2025.xlsx")
print("✅ File saved to: C:\\Users\\GOUR CHANDRA PAUL\\nifty_prediction_2025.xlsx")







