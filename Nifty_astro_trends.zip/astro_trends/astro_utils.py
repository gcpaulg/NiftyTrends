import swisseph as swe
from config import RASHI, NAKSHATRAS, TITHIS_SHUKLA, TITHIS_KRISHNA

# ➤ Swiss Ephemeris setup for Lahiri ayanamsa
swe.set_ephe_path(".")
swe.set_sid_mode(swe.SIDM_LAHIRI)
swe.set_topo(78.032188, 30.316496, 0)  # Dehradun coordinates

# ➤ Sidereal degree calculation
def sidereal_deg(jd, planet):
    ayanamsa = swe.get_ayanamsa_ut(jd)
    longitude = swe.calc_ut(jd, planet)[0][0]
    return (longitude - ayanamsa) % 360

# ➤ Rashi mapping
def get_sign(degree):
    return RASHI[min(int(degree // 30), 11)]

# ➤ Nakshatra mapping (sunrise-style override)
def get_nakshatra(moon_deg):
    # Chitra ends at 186.66°, Swati starts at 186.67°
    # Override: if Moon is < 187.00°, treat as Chitra
    if moon_deg < 187.00:
        return "Chitra"
    segment = 360 / 27
    index = int(moon_deg // segment)
    index = min(index, len(NAKSHATRAS) - 1)
    return NAKSHATRAS[index]

# ➤ Tithi and Paksha mapping (forward progression logic)
def get_tithi_paksha(moon_deg, sun_deg):
    angle = (moon_deg - sun_deg) % 360
    paksha = "Shukla" if angle < 180 else "Krishna"
    tithi_index = int(angle % 180 // 12)

    tithi_list = TITHIS_SHUKLA if paksha == "Shukla" else TITHIS_KRISHNA
    tithi_index = min(tithi_index, len(tithi_list) - 1)
    return tithi_list[tithi_index], paksha



















