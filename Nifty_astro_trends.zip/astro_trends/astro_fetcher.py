

import swisseph as swe

# Location: Dehradun, India
LATITUDE = 30.316496
LONGITUDE = 78.032188
swe.set_topo(LONGITUDE, LATITUDE, 0)

# Sidereal mode (KP-compatible)
swe.set_sid_mode(swe.SIDM_LAHIRI)

def get_astro_details(dt):
    jd = swe.julday(dt.year, dt.month, dt.day)
    planets = {}

    # Planet codes and names
    planet_codes = {
        swe.SUN: "Sun",
        swe.MOON: "Moon",
        swe.MERCURY: "Mercury",
        swe.VENUS: "Venus",
        swe.MARS: "Mars"
    }

    # Extract zodiac signs only
    for code, name in planet_codes.items():
        sign = map_sign(swe.calc_ut(jd, code)[0])
        planets[name] = sign

        if name == "Moon":
            moon_deg = swe.calc_ut(jd, code)[0]
        if name == "Sun":
            sun_deg = swe.calc_ut(jd, code)[0]

    # Add Nakshatra, Tithi, Paksha
    planets["Nakshatra"] = get_nakshatra(moon_deg)
    tithi, paksha = get_tithi(moon_deg, sun_deg)
    planets["Tithi"] = tithi
    planets["Paksha"] = paksha

    return planets

def map_sign(degree):
    signs = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
             "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"]
    return signs[int(degree // 30)]

def get_nakshatra(moon_deg):
    nakshatras = [
        "Ashwini", "Bharani", "Krittika", "Rohini", "Mrigashira", "Ardra",
        "Punarvasu", "Pushya", "Ashlesha", "Magha", "Purva Phalguni", "Uttara Phalguni",
        "Hasta", "Chitra", "Swati", "Vishakha", "Anuradha", "Jyeshta",
        "Mula", "Purva Ashadha", "Uttara Ashadha", "Shravana", "Dhanishta", "Shatabhisha",
        "Purva Bhadrapada", "Uttara Bhadrapada", "Revati"
    ]
    index = int((moon_deg % 360) // (360 / 27))
    return nakshatras[index]

def get_tithi(moon_deg, sun_deg):
    angle = (moon_deg - sun_deg) % 360
    tithi_num = int(angle // 12)
    paksha = "Shukla" if tithi_num < 15 else "Krishna"
    tithis = [
        "Pratipada", "Dwitiya", "Tritiya", "Chaturthi", "Panchami", "Shashti",
        "Saptami", "Ashtami", "Navami", "Dashami", "Ekadashi", "Dwadashi",
        "Trayodashi", "Chaturdashi", "Purnima", "Amavasya"
    ]
    return tithis[tithi_num % 15], paksha


