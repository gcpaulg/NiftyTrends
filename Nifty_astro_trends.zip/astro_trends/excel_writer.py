from openpyxl import Workbook

def create_workbook():
    wb = Workbook()
    ws = wb.active
    ws.title = "Nifty Prediction 2027"
    ws.append([
        "Date", "Day", "Sun Sign", "Moon Sign", "Trend1 (Sun + Moon)",
        "Moon Nakshatra", "Trend2 (Sun + Nakshatra)", "Tithi", "Paksha",
        "Trend3 (Sun + Tithi + Paksha)", "Actual", "Mercury Sign", "Venus Sign", "Mars Sign"
    ])
    return wb, ws



