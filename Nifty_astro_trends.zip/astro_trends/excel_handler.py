import pandas as pd
from config import NEW_FILE, COLUMNS

def read_original(file_path):
    return pd.read_excel(file_path)

def create_new(df):
    df.to_excel(NEW_FILE, index=False)

def reorder_columns(df):
    return df[[col for col in COLUMNS if col in df.columns]]

