from datetime import date, timedelta

def generate_calendar_rows(year):
    base = date(year, 1, 1)
    for i in range(365):
        current = base + timedelta(days=i)
        yield {
            'datetime': current,
            'date': current.strftime("%Y-%m-%d"),
            'day': current.strftime("%A")
        }

